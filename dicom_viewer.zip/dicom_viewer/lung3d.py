"""観点7: 第5回で抽出した肺マスク(連続TIFF)のボリュームレンダリング (VTK)"""
import numpy as np
from scipy import ndimage as ndi
from PySide6.QtWidgets import QMainWindow, QApplication
from PySide6.QtGui import QAction
from PySide6.QtCore import Qt
from vtkmodules.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor
from vtkmodules.util import numpy_support
import vtkmodules.vtkRenderingOpenGL2  # noqa: F401 (レンダラ登録)
import vtkmodules.vtkRenderingVolumeOpenGL2  # noqa: F401
import vtkmodules.vtkInteractionStyle  # noqa: F401
from vtkmodules.vtkCommonDataModel import vtkImageData, vtkPiecewiseFunction
from vtkmodules.vtkRenderingCore import (vtkRenderer, vtkVolume, vtkVolumeProperty,
                                         vtkColorTransferFunction)
from vtkmodules.vtkRenderingVolume import vtkFixedPointVolumeRayCastMapper


class Lung3DWindow(QMainWindow):
    """mask: (Z, Y, X) bool, spacing: (sx, sy, sz) [mm]"""

    def __init__(self, mask, spacing, parent=None, step=2, title=""):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.setWindowTitle("肺領域 ボリュームレンダリング " + title)
        self.resize(800, 800)
        self.step = step
        self.spacing = spacing
        self.flip_z = False

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            small = mask[:, ::step, ::step].astype(np.float32)  # Z は間引かない
            # 二値マスクを軽く平滑化して階段状のアーティファクトを抑える
            self.scalar = ndi.gaussian_filter(small, sigma=(2.0, 1.5, 1.5))  # (Z, Y, X)
        finally:
            QApplication.restoreOverrideCursor()

        self.vtk_widget = QVTKRenderWindowInteractor(self)
        self.setCentralWidget(self.vtk_widget)
        self.ren = vtkRenderer()
        self.ren.SetBackground(0.05, 0.05, 0.08)
        self.vtk_widget.GetRenderWindow().AddRenderer(self.ren)

        self.view_name = "ZX"
        tb = self.addToolBar("View")
        tb.setMovable(False)
        for name, tip in (("XY", "XY面(体軸断面)の向きで表示"),
                          ("YZ", "YZ面(矢状断)の向きで表示"),
                          ("ZX", "ZX面(冠状断・正面)の向きで表示")):
            a = QAction(name, self)
            a.setToolTip(tip)
            a.triggered.connect(lambda _=False, n=name: self.set_view(n))
            tb.addAction(a)
        tb.addSeparator()
        act = QAction("上下(Z)反転", self)
        act.setCheckable(True)
        act.toggled.connect(self.set_flip)
        tb.addAction(act)

        self.vol_actor = None
        self.build()
        self.iren = self.vtk_widget.GetRenderWindow().GetInteractor()
        self.iren.Initialize()
        self.iren.Start()
        self.vtk_widget.GetRenderWindow().Render()

    def build(self):
        if self.vol_actor is not None:
            self.ren.RemoveVolume(self.vol_actor)
        data = self.scalar[::-1] if self.flip_z else self.scalar
        z, y, x = data.shape
        sx, sy, sz = self.spacing
        img = vtkImageData()
        img.SetDimensions(x, y, z)
        img.SetSpacing(sx * self.step, sy * self.step, sz)
        arr = numpy_support.numpy_to_vtk(np.ascontiguousarray(data).ravel(), deep=True)
        img.GetPointData().SetScalars(arr)
        self._img, self._arr = img, arr  # 参照保持

        opacity = vtkPiecewiseFunction()
        for v, o in ((0.0, 0.0), (0.15, 0.0), (0.4, 0.35), (0.7, 0.8), (1.0, 1.0)):
            opacity.AddPoint(v, o)
        color = vtkColorTransferFunction()
        for v, c in ((0.0, (0.2, 0.4, 0.9)), (0.5, (0.9, 0.6, 0.5)), (1.0, (1.0, 0.85, 0.8))):
            color.AddRGBPoint(v, *c)
        prop = vtkVolumeProperty()
        prop.SetScalarOpacity(opacity)
        prop.SetColor(color)
        prop.SetInterpolationTypeToLinear()
        prop.ShadeOn()

        mapper = vtkFixedPointVolumeRayCastMapper()  # CPU レンダリング（GPU非依存）
        mapper.SetInputData(img)
        self.vol_actor = vtkVolume()
        self.vol_actor.SetMapper(mapper)
        self.vol_actor.SetProperty(prop)
        self.ren.AddVolume(self.vol_actor)

        self.set_view(self.view_name, render=False)

    def set_view(self, name, render=True):
        """XY: Z軸方向から(体軸断面) / YZ: X軸方向から(矢状断) / ZX: Y軸方向から(冠状断・正面)"""
        self.view_name = name
        cx, cy, cz = self._img.GetCenter()
        d = 1000.0
        zs = 1 if self.flip_z else -1  # 反転時は足側が +Z 側になる
        upz = -1 if self.flip_z else 1  # 頭側が画面上になる向き
        cam = self.ren.GetActiveCamera()
        cam.SetFocalPoint(cx, cy, cz)
        if name == "XY":
            cam.SetPosition(cx, cy, cz + zs * d)
            cam.SetViewUp(0, -1, 0)   # 前方(y小)が画面上
        elif name == "YZ":
            cam.SetPosition(cx + d, cy, cz)
            cam.SetViewUp(0, 0, upz)
        else:  # ZX
            cam.SetPosition(cx, cy - d, cz)
            cam.SetViewUp(0, 0, upz)
        self.ren.ResetCamera()
        if render:
            self.vtk_widget.GetRenderWindow().Render()

    def set_flip(self, f):
        self.flip_z = f
        self.build()
        self.vtk_widget.GetRenderWindow().Render()

    def closeEvent(self, ev):
        # OpenGL コンテキストを先に解放してから閉じる（終了時の wglMakeCurrent エラー対策）
        try:
            self.vtk_widget.Finalize()
        except Exception:
            pass
        super().closeEvent(ev)
