"""DICOM 読込み・ウィンドウ処理・肺領域抽出（GUI非依存）"""
import os
import numpy as np
from scipy import ndimage as ndi


class Volume:
    """vol: (Z, Y, X) の HU 値 (float32), spacing: (sx, sy, sz) [mm]"""

    def __init__(self, vol, spacing, wl=40.0, ww=400.0):
        self.vol = vol
        self.sx, self.sy, self.sz = spacing
        self.wl, self.ww = wl, ww

    @property
    def shape_xyz(self):
        z, y, x = self.vol.shape
        return x, y, z


def _first(v, default=None):
    """pydicom の MultiValue 等から先頭値を取り出す"""
    if v is None:
        return default
    try:
        if hasattr(v, "__len__") and not isinstance(v, (str, bytes)):
            return float(v[0])
        return float(v)
    except Exception:
        return default


def load_dicom_files(paths, progress=None):
    import pydicom
    items = []
    for i, p in enumerate(paths):
        try:
            ds = pydicom.dcmread(p, force=True)
            if not hasattr(ds, "PixelData"):
                continue
            ds.Rows, ds.Columns  # 画像でないものを除外
            items.append(ds)
        except Exception:
            continue
        if progress:
            progress(i + 1, len(paths))
    if not items:
        raise ValueError("読み込めるDICOM画像が見つかりませんでした")

    # 同一シリーズ・同一サイズのみ（最頻値）
    from collections import Counter
    key = lambda d: (getattr(d, "SeriesInstanceUID", ""), int(d.Rows), int(d.Columns))
    common = Counter(key(d) for d in items).most_common(1)[0][0]
    items = [d for d in items if key(d) == common]

    # スライス順の決定
    def zpos(d):
        ipp = getattr(d, "ImagePositionPatient", None)
        iop = getattr(d, "ImageOrientationPatient", None)
        if ipp is not None and iop is not None:
            r = np.array(iop[:3], float)
            c = np.array(iop[3:], float)
            n = np.cross(r, c)
            return float(np.dot(n, np.array(ipp, float)))
        if ipp is not None:
            return float(ipp[2])
        return float(getattr(d, "InstanceNumber", 0))

    items.sort(key=zpos)
    zs = np.array([zpos(d) for d in items])

    slices = []
    for d in items:
        arr = d.pixel_array.astype(np.float32)
        slope = _first(getattr(d, "RescaleSlope", None), 1.0)
        icpt = _first(getattr(d, "RescaleIntercept", None), 0.0)
        slices.append(arr * slope + icpt)
    vol = np.stack(slices, axis=0)

    ps = getattr(items[0], "PixelSpacing", [1.0, 1.0])
    sy, sx = float(ps[0]), float(ps[1])  # [行間隔, 列間隔]
    if len(zs) > 1 and np.median(np.abs(np.diff(zs))) > 0:
        sz = float(np.median(np.abs(np.diff(zs))))
    else:
        sz = _first(getattr(items[0], "SliceThickness", None), 1.0)

    wl = _first(getattr(items[0], "WindowCenter", None), 40.0)
    ww = _first(getattr(items[0], "WindowWidth", None), 400.0)
    return Volume(vol, (sx, sy, sz), wl, ww)


def collect_files(folder):
    out = []
    for root, _, files in os.walk(folder):
        for f in files:
            out.append(os.path.join(root, f))
    return sorted(out)


def apply_window(img, wl, ww):
    """HU 画像 -> 8bit グレースケール"""
    ww = max(float(ww), 1.0)
    lo = wl - ww / 2.0
    out = (img - lo) / ww * 255.0
    return np.clip(out, 0, 255).astype(np.uint8)


def get_slice(volume, plane, idx):
    """表示用の2D配列を返す。上方向が頭側になるよう Z を反転する。"""
    v = volume.vol
    if plane == "axial":
        return v[idx, :, :]
    if plane == "coronal":
        return v[::-1, idx, :]
    if plane == "sagittal":
        return v[::-1, :, idx]
    raise ValueError(plane)


def plane_geometry(volume, plane):
    """(最大スライス番号, 水平方向mm/px, 垂直方向mm/px)"""
    x, y, z = volume.shape_xyz
    if plane == "axial":
        return z - 1, volume.sx, volume.sy
    if plane == "coronal":
        return y - 1, volume.sx, volume.sz
    return x - 1, volume.sy, volume.sz


def segment_lung(vol_hu, step=2):
    """肺領域の簡易抽出（閾値 + 連結成分）。ダウンサンプリングした (mask, step) を返す。
    1) HU < -400 を空気とみなす  2) 体の外側の空気（境界に接する成分）を除去
    3) 体積上位2成分を肺とする   4) スライス毎に穴埋め"""
    small = vol_hu[::step, ::step, ::step]
    air = small < -400
    lab, n = ndi.label(air)
    if n == 0:
        return np.zeros_like(air), step
    border = set(np.unique(np.concatenate([
        lab[:, 0, :].ravel(), lab[:, -1, :].ravel(),
        lab[:, :, 0].ravel(), lab[:, :, -1].ravel()])))
    sizes = ndi.sum(air, lab, index=np.arange(1, n + 1))
    cand = [(s, i + 1) for i, s in enumerate(sizes) if (i + 1) not in border]
    cand.sort(reverse=True)
    mask = np.zeros_like(air)
    for _, i in cand[:2]:
        mask |= lab == i
    for z in range(mask.shape[0]):
        mask[z] = ndi.binary_fill_holes(mask[z])
    return mask, step


def load_mask_tiff(path):
    """第5回で作成した連続(マルチページ)TIFFの肺マスクを (Z, Y, X) の bool 配列で読む。
    0 より大きい画素（白）を肺とみなす。RGB/RGBA の場合はグレースケール化して判定。"""
    from PIL import Image, ImageSequence
    frames = []
    with Image.open(path) as im:
        for fr in ImageSequence.Iterator(im):
            a = np.asarray(fr.convert("L"))
            frames.append(a > 127)
    if not frames:
        raise ValueError("TIFF から画像を読み込めませんでした")
    shapes = {f.shape for f in frames}
    if len(shapes) != 1:
        raise ValueError("TIFF 内の画像サイズが一致していません")
    return np.stack(frames, axis=0)
