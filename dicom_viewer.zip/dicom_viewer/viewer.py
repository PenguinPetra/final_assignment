"""医用画像処理実験 最終課題: DICOM MPR Viewer (Axial / Coronal / Sagittal)
起動: python viewer.py"""
import sys
import numpy as np
from PySide6.QtCore import Qt, Signal, QRectF, QPointF
from PySide6.QtGui import QAction, QImage, QPainter, QPen, QColor
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QSlider, QFileDialog, QMessageBox, QProgressDialog,
    QDialog, QFormLayout, QDoubleSpinBox, QDialogButtonBox, QPushButton)

import core

PLANES = ("axial", "coronal", "sagittal")
TITLES = {"axial": "Axial", "coronal": "Coronal", "sagittal": "Sagittal"}


class SliceView(QWidget):
    """スライス画像を自前で描画する Viewer。十字線(他2面の位置)も描画する。"""
    clicked = Signal(float, float)  # 画像座標 (col, row)

    def __init__(self):
        super().__init__()
        self.setMinimumSize(200, 200)
        self.setMouseTracking(False)
        self.qimg = None
        self._buf = None
        self.sx = self.sy = 1.0          # mm / px (水平, 垂直)
        self.line_col = None             # 縦線の位置 (画像列, px)
        self.line_row = None             # 横線の位置 (画像行, px)
        self.line_color = QColor(0, 255, 0)

    def set_image(self, img8, sx, sy, line_col, line_row):
        self._buf = np.ascontiguousarray(img8)
        h, w = self._buf.shape
        self.qimg = QImage(self._buf.data, w, h, w, QImage.Format.Format_Grayscale8)
        self.sx, self.sy = sx, sy
        self.line_col, self.line_row = line_col, line_row
        self.update()

    def _image_rect(self):
        """物理サイズ比を保ったまま中央に収めた描画矩形"""
        assert self.qimg is not None
        w_mm = self.qimg.width() * self.sx
        h_mm = self.qimg.height() * self.sy
        s = min(self.width() / w_mm, self.height() / h_mm)
        w, h = w_mm * s, h_mm * s
        return QRectF((self.width() - w) / 2, (self.height() - h) / 2, w, h)

    def paintEvent(self, _):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(15, 15, 20))
        if self.qimg is None:
            return
        r = self._image_rect()
        p.drawImage(r, self.qimg)
        p.setPen(QPen(self.line_color, 1))
        if self.line_col is not None:
            x = r.left() + (self.line_col + 0.5) / self.qimg.width() * r.width()
            p.drawLine(QPointF(x, r.top()), QPointF(x, r.bottom()))
        if self.line_row is not None:
            y = r.top() + (self.line_row + 0.5) / self.qimg.height() * r.height()
            p.drawLine(QPointF(r.left(), y), QPointF(r.right(), y))

    def _emit(self, ev):
        if self.qimg is None:
            return
        qimg = self.qimg
        r = self._image_rect()
        c = (ev.position().x() - r.left()) / r.width() * qimg.width()
        rw = (ev.position().y() - r.top()) / r.height() * qimg.height()
        self.clicked.emit(c - 0.5, rw - 0.5)

    def mousePressEvent(self, ev):
        if ev.button() == Qt.MouseButton.LeftButton:
            self._emit(ev)

    def mouseMoveEvent(self, ev):
        if ev.buttons() & Qt.MouseButton.LeftButton:
            self._emit(ev)


def make_slider(lo, hi, val):
    s = QSlider(Qt.Orientation.Horizontal)
    s.setRange(lo, hi)
    s.setValue(val)
    return s


class Panel(QWidget):
    """1つの断面 = 画像 + スライス位置/WL/WW スライダー"""
    changed = Signal()

    def __init__(self, plane):
        super().__init__()
        self.plane = plane
        self.view = SliceView()
        self.s_pos = make_slider(0, 0, 0)
        self.s_wl = make_slider(-1500, 3000, 40)
        self.s_ww = make_slider(1, 4000, 400)
        self.l_pos, self.l_wl, self.l_ww = QLabel(), QLabel(), QLabel()
        for l in (self.l_pos, self.l_wl, self.l_ww):
            l.setMinimumWidth(90)
        lay = QVBoxLayout(self)
        title = QLabel(TITLES[plane])
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("font-weight:bold;")
        lay.addWidget(title)
        lay.addWidget(self.view, 1)
        grid = QGridLayout()
        for i, (name, s, l) in enumerate((("Slice", self.s_pos, self.l_pos),
                                          ("WL", self.s_wl, self.l_wl),
                                          ("WW", self.s_ww, self.l_ww))):
            grid.addWidget(QLabel(name), i, 0)
            grid.addWidget(s, i, 1)
            grid.addWidget(l, i, 2)
        lay.addLayout(grid)
        self.btn_reset = QPushButton("WL/WW リセット")
        lay.addWidget(self.btn_reset)
        for s in (self.s_pos, self.s_wl, self.s_ww):
            s.valueChanged.connect(lambda _=None: self.changed.emit())


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("DICOM MPR Viewer")
        self.resize(1500, 650)
        self.volume = None
        self.lung_win = None
        self.panels = {p: Panel(p) for p in PLANES}

        central = QWidget()
        h = QHBoxLayout(central)
        for p in PLANES:
            h.addWidget(self.panels[p], 1)
            self.panels[p].changed.connect(lambda pl=p: self.on_slider(pl))
            self.panels[p].view.clicked.connect(lambda c, r, pl=p: self.on_click(pl, c, r))
        self.setCentralWidget(central)
        self.statusBar().showMessage("「ファイル」メニューから DICOM / TIFF を読み込んでください")

        for p in PLANES:
            self.panels[p].btn_reset.clicked.connect(lambda _=False, pl=p: self.reset_wlww(pl))

        m = self.menuBar().addMenu("ファイル(&F)")
        a1 = QAction("DICOM フォルダを開く...", self, shortcut="Ctrl+O", triggered=self.open_folder)
        a2 = QAction("DICOM ファイルを開く...", self, shortcut="Ctrl+Shift+O", triggered=self.open_files)
        a3 = QAction("TIFF 画像（連続TIFF）を開く...", self, shortcut="Ctrl+T", triggered=self.open_tiff)
        a4 = QAction("画素間隔(スライスサイズ)の設定...", self, triggered=self.change_spacing)
        a5 = QAction("終了", self, shortcut="Ctrl+Q", triggered=self.close)
        m.addActions([a1, a2, a3]); m.addSeparator(); m.addAction(a4); m.addSeparator(); m.addAction(a5)
        m3 = self.menuBar().addMenu("3D")
        m3.addAction(QAction("現在の画像から肺を3D表示", self, triggered=self.open_lung3d))
        mh = self.menuBar().addMenu("ヘルプ(&H)")
        mh.addAction(QAction("操作方法", self, shortcut="F1", triggered=self.show_help))
        mh.addAction(QAction("バージョン情報", self, triggered=self.show_about))
        self.set_enabled(False)

    # ---------- 読込み ----------
    def set_enabled(self, f):
        for p in self.panels.values():
            p.setEnabled(f)

    def open_folder(self):
        d = QFileDialog.getExistingDirectory(self, "DICOM フォルダを選択")
        if d:
            self.load(core.collect_files(d))

    def open_files(self):
        fs, _ = QFileDialog.getOpenFileNames(self, "DICOM ファイルを選択（複数可）", "",
                                             "DICOM (*.dcm *.DCM *.ima *.IMA);;All files (*)")
        if fs:
            self.load(fs)

    def load(self, paths):
        dlg = QProgressDialog("DICOM 読込み中...", "", 0, len(paths), self)
        dlg.setCancelButton(None)
        dlg.setWindowModality(Qt.WindowModality.WindowModal)
        dlg.show()

        def prog(i, n):
            dlg.setValue(i)
            QApplication.processEvents()
        try:
            vol = core.load_dicom_files(paths, prog)
        except Exception as e:
            dlg.close()
            QMessageBox.critical(self, "読込みエラー", str(e))
            return
        dlg.close()
        self.set_volume(vol)

    def open_tiff(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "TIFF 画像を選択（連続TIFF可）", "", "TIFF (*.tif *.tiff);;All files (*)")
        if not path:
            return
        try:
            vol = core.load_tiff_volume(path)
        except Exception as e:
            QMessageBox.critical(self, "TIFF 読込みエラー", f"{type(e).__name__}: {e}")
            return
        # 初期表示: スライスサイズ(画素間隔)を設定するダイアログ
        sp = self.ask_spacing((vol.sx, vol.sy, vol.sz), vol.vol.shape,
                              "TIFF には画素間隔の情報がないため、必要に応じて変更してください。\n"
                              "(XY=画素サイズ, Z=スライス間隔。わからなければ 1 のままで構いません)")
        if sp is not None:
            vol.sx, vol.sy, vol.sz = sp
        self.set_volume(vol)

    def set_volume(self, vol):
        self.volume = vol
        x, y, z = vol.shape_xyz
        n = {"axial": z, "coronal": y, "sagittal": x}
        for pl, panel in self.panels.items():
            for s in (panel.s_pos, panel.s_wl, panel.s_ww):
                s.blockSignals(True)
            panel.s_pos.setRange(0, n[pl] - 1)
            panel.s_pos.setValue(n[pl] // 2)
            panel.s_wl.setRange(*vol.wl_range)
            panel.s_ww.setRange(*vol.ww_range)
            panel.s_wl.setValue(int(vol.wl))
            panel.s_ww.setValue(int(vol.ww))
            for s in (panel.s_pos, panel.s_wl, panel.s_ww):
                s.blockSignals(False)
        self.set_enabled(True)
        self.statusBar().showMessage(
            f"読込み完了: {x}x{y}x{z} voxels, spacing=({vol.sx:.2f}, {vol.sy:.2f}, {vol.sz:.2f}) mm")
        self.refresh()

    def reset_wlww(self, plane):
        """その断面の WL/WW を読込み時の値に戻す"""
        v = self.volume
        if v is None:
            return
        p = self.panels[plane]
        for s in (p.s_wl, p.s_ww):
            s.blockSignals(True)
        p.s_wl.setValue(int(v.wl))
        p.s_ww.setValue(int(v.ww))
        for s in (p.s_wl, p.s_ww):
            s.blockSignals(False)
        self.refresh()

    def change_spacing(self):
        v = self.volume
        if v is None:
            QMessageBox.information(self, "画素間隔", "先に画像を読み込んでください")
            return
        sp = self.ask_spacing((v.sx, v.sy, v.sz), v.vol.shape, "")
        if sp is not None:
            v.sx, v.sy, v.sz = sp
            self.statusBar().showMessage(
                f"画素間隔を変更: ({v.sx:.3g}, {v.sy:.3g}, {v.sz:.3g}) mm")
            self.refresh()

    # ---------- 位置 (x, y, z) ----------
    def position(self):
        return (self.panels["sagittal"].s_pos.value(),
                self.panels["coronal"].s_pos.value(),
                self.panels["axial"].s_pos.value())

    def on_slider(self, _plane):
        self.refresh()

    def on_click(self, plane, col, row):
        """画像クリック/ドラッグでも他2面の位置を移動（スライダーに反映）"""
        if self.volume is None:
            return
        x, y, z = self.volume.shape_xyz
        col, row = int(round(col)), int(round(row))
        pp = self.panels
        if plane == "axial":
            targets = {"sagittal": col, "coronal": row}
        elif plane == "coronal":
            targets = {"sagittal": col, "axial": z - 1 - row}
        else:
            targets = {"coronal": col, "axial": z - 1 - row}
        for pl, v in targets.items():
            s = pp[pl].s_pos
            s.blockSignals(True)
            s.setValue(max(0, min(s.maximum(), v)))
            s.blockSignals(False)
        self.refresh()

    # ---------- 描画 ----------
    def refresh(self):
        v = self.volume
        if v is None:
            return
        px, py, pz = self.position()
        _, _, nz = v.shape_xyz
        zrow = nz - 1 - pz  # Coronal/Sagittal は頭側が上になるよう反転しているため
        lines = {  # plane: (縦線の列, 横線の行)
            "axial": (px, py),
            "coronal": (px, zrow),
            "sagittal": (py, zrow),
        }
        for pl, panel in self.panels.items():
            _, sh, sv = core.plane_geometry(v, pl)
            wl, ww = panel.s_wl.value(), panel.s_ww.value()
            img = core.apply_window(core.get_slice(v, pl, panel.s_pos.value()), wl, ww)
            panel.view.set_image(img, sh, sv, *lines[pl])
            panel.l_pos.setText(f"{panel.s_pos.value() + 1}/{panel.s_pos.maximum() + 1}")
            panel.l_wl.setText(str(wl))
            panel.l_ww.setText(str(ww))

    # ---------- 3D ----------
    def open_lung3d(self):
        """現在開いている画像から肺の3Dモデルを作って表示する"""
        v = self.volume
        if v is None:
            QMessageBox.information(self, "3D", "先に DICOM または TIFF を読み込んでください")
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            if v.source == "tif":
                # TIFF（第5回の肺マスク等）: 画素値の中間値より大きい部分を対象領域とする
                lo, hi = float(v.vol.min()), float(v.vol.max())
                mask = v.vol > (lo + hi) / 2.0
                spacing, step = (v.sx, v.sy, v.sz), 2
            else:
                # DICOM(HU値): 閾値＋連結成分による簡易肺抽出 (XY を 1/2 に縮小して処理)
                mask, st = core.segment_lung(v.vol, step=2, step_z=1)
                spacing, step = (v.sx * st, v.sy * st, v.sz), 1
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, "3D エラー", f"{type(e).__name__}: {e}")
            return
        QApplication.restoreOverrideCursor()
        if not mask.any():
            QMessageBox.information(self, "3D", "表示する領域が見つかりませんでした")
            return
        try:
            from lung3d import Lung3DWindow
            self.close_lung_win()
            note = f"(spacing {v.sx:.3g}, {v.sy:.3g}, {v.sz:.3g} mm)"
            self.lung_win = Lung3DWindow(mask, spacing, self, step=step, title=note)
            self.lung_win.show()
        except Exception as e:
            QMessageBox.critical(self, "3D エラー", f"{type(e).__name__}: {e}")

    def ask_spacing(self, init, shape, message=""):
        dlg = QDialog(self)
        dlg.setWindowTitle("画素間隔(スライスサイズ)の設定")
        form = QFormLayout(dlg)
        msg = f"画像: {shape[2]} x {shape[1]} x {shape[0]} voxels"
        if message:
            msg += "\n" + message
        form.addRow(QLabel(msg))
        boxes = []
        for name, val in zip(("X (mm/px)", "Y (mm/px)", "Z (スライス間隔 mm)"), init):
            b = QDoubleSpinBox()
            b.setDecimals(3)
            b.setRange(0.01, 50.0)
            b.setValue(val)
            form.addRow(name, b)
            boxes.append(b)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        form.addRow(bb)
        if dlg.exec() != QDialog.Accepted:
            return None
        return tuple(b.value() for b in boxes)

    # ---------- ヘルプ ----------
    def show_help(self):
        QMessageBox.information(self, "操作方法", (
            "【読込み】 ファイル → DICOM フォルダ / DICOM ファイル / TIFF 画像\n"
            "  TIFF 読込み時は画素間隔(スライスサイズ)の設定画面が開きます。\n"
            "  後から ファイル → 画素間隔の設定 でも変更できます。\n\n"
            "【表示】 Axial / Coronal / Sagittal の3断面。緑の線は他2断面の位置です。\n"
            "  画像を左クリック／ドラッグすると他2断面の位置が移動します。\n\n"
            "【スライダー】 Slice=スライス位置, WL=ウィンドウレベル, WW=ウィンドウ幅。\n"
            "  「WL/WW リセット」で読込み時の値に戻ります（断面ごと）。\n\n"
            "【3D】 3D → 現在の画像から肺を3D表示\n"
            "  DICOM: HU値から肺を簡易抽出して表示 / TIFF: 白い部分(肺マスク)を表示。\n"
            "  3D画面: 左ドラッグ=回転, 右ドラッグ=拡大縮小, 中ドラッグ=移動,\n"
            "  XY/YZ/ZX ボタンで視点切替, 「上下(Z)反転」で上下が逆の場合に修正。"))

    def show_about(self):
        QMessageBox.about(self, "バージョン情報",
                          "DICOM MPR Viewer\n医用画像処理実験 最終課題\nPython / PySide6 / pydicom / VTK")

    def close_lung_win(self):
        if self.lung_win is not None:
            try:
                self.lung_win.close()  # VTK ウィンドウを先に閉じる
            except RuntimeError:  # ユーザーが既に閉じて削除済みの場合
                pass
            self.lung_win = None

    def closeEvent(self, ev):
        self.close_lung_win()
        super().closeEvent(ev)


def main():
    app = QApplication(sys.argv)
    w = MainWindow()
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
